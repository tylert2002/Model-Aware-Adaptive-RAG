# Set dataset:
local dataset = "musique";
local retrieval_corpus_name = dataset;
local add_pinned_paras = if dataset == "iirc" then true else false;
local valid_qids = ["2hop__804754_52230", "2hop__292995_8796", "2hop__496817_701819", "2hop__154225_727337", "2hop__642271_608104", "2hop__439265_539716", "2hop__195347_20661", "2hop__131516_53573", "2hop__427213_79175", "3hop1__443556_763924_573834", "2hop__782642_52667", "2hop__861128_15822", "4hop3__703974_789671_24078_24137", "3hop1__61746_67065_43617", "4hop3__463724_100414_35260_54090"];
local prompt_reader_args = {
    "filter_by_key_values": {
        "qid": valid_qids
    },
    "order_by_key": "qid",
    "estimated_generation_length": 300,
    "shuffle": false,
    "model_length_limit": 8000,
};

# (Potentially) Hyper-parameters:
# null means it's unused.
local llm_retrieval_count = null;
local llm_map_count = null;
local bm25_retrieval_count = null;
local rc_context_type_ = "no"; # Choices: no, gold, gold_with_n_distractors
local distractor_count = null; # Choices: 1, 2, 3
local rc_context_type = (
    if rc_context_type_ == "gold_with_n_distractors"
    then "gold_with_" + distractor_count + "_distractors"  else rc_context_type_
);
local rc_qa_type = "cot"; # Choices: direct, cot

{
    "start_state": "generate_question",
    "end_state": "[EOQ]",
    "models": {
        "generate_question": {
            "name": "copy_question",
            "next_model": "generate_answer",
            "eoq_after_n_calls": 1,
            "end_state": "[EOQ]",
        },
        "generate_answer": {
            "name": "llmqa",
            "next_model": if std.endsWith(rc_qa_type, "cot") then "extract_answer" else null,
            "prompt_file": "prompts/"+dataset+"/"+rc_context_type+"_context_"+rc_qa_type+"_qa_codex.txt",
            "prompt_reader_args": prompt_reader_args,
            "end_state": "[EOQ]",
            "gen_model": "gpt3",
            "engine": "gpt-3.5-turbo-instruct",
            "retry_after_n_seconds": 50,
            "add_context": add_pinned_paras,
        },
        "extract_answer": {
            "name": "answer_extractor",
            "query_source": "last_answer",
            "regex": ".* answer is:? (.*)\\.?",
            "match_all_on_failure": true,
            "remove_last_fullstop": true,
        }
    },
    "reader": {
        "name": "multi_para_rc",
        "add_paras": false,
        "add_gold_paras": false,
        "add_pinned_paras": add_pinned_paras,
    },
    "prediction_type": "answer"
}